function hideObject(){
var mytextobject = document.getElementById("textObject")
	if (window.getComputedStyle(mytextobject).display === 'block'){
		mytextobject.style.display = 'none';
		return;
	}
		mytextobject.style.display = 'block';
}