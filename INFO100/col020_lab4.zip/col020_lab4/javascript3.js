function openInNewTab(url) {
  var win = window.open(url);
  win.focus();
}