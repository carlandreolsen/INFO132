function thisIsFunction(){
	document.getElementById("oppgtext").style.fontSize = "15px";
}
