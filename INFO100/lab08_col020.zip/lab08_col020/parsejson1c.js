var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        var variablus = JSON.parse(this.responseText);
        if(variablus.id == 123){
            document.getElementById("question").innerHTML = "Question: "+variablus.text + " - " + variablus.name;
        }
    }
};
xmlhttp.open("GET", "./oppgave1a.json", true);
xmlhttp.send();


var xmlhttp2 = new XMLHttpRequest();
xmlhttp2.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        var myObjt = JSON.parse(this.responseText);        
        if(myObjt.id == 123){
            document.getElementById("answer").innerHTML = "<br>"+"Answer: "+myObjt.answer + " - " +myObjt.name;
        }
    }
};
xmlhttp2.open("GET", "./oppgave1d.json", true);
xmlhttp2.send();

