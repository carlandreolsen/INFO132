#Operatoren + mellom to tekststrenger legger de sammen til en streng.
#Eksempel: "str"+"ing" = "string"
#
#Operatoren * mellom en tekststreng og et heltall n legger strengen sammen med seg selv n ganger.
#Eksempel: "str,"*4 = "str,str,str,str,"
mittTall = 123
minTekst = str(mittTall)
mittTall = mittTall*10+1
minTekst = str(mittTall)
print(mittTall)
print(minTekst)
print(mittTall*2)
print(minTekst*2)
