from random import randrange as rr
fornavn = input("Skriv inn ditt fornavn: ")
etternavn = input("Skriv inn ditt etternavn: ")
print ("Hei, "+fornavn+" "+"A"*(rr(2)+1)+"a"*rr(6)+" "+etternavn+"!")
